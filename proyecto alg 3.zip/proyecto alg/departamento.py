class Departamento:
    """Clase que representa un departamento en el MET."""
    def __init__(self, departmentId, displayName):
        self.departmentId = departmentId
        self.displayName = displayName