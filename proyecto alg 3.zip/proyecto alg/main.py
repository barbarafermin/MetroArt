from menu_funciones import menu
m = menu() 

def main():
    m.mostrar_menu()

main()
